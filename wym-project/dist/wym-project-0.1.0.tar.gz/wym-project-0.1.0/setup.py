# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['wym_project']

package_data = \
{'': ['*'], 'wym_project': ['static/*', 'templates/*']}

install_requires = \
['Flask>=2.2.2,<3.0.0']

setup_kwargs = {
    'name': 'wym-project',
    'version': '0.1.0',
    'description': "c'est notre projet",
    'long_description': None,
    'author': 'Alex',
    'author_email': 'alexandra.cecile.penin@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
